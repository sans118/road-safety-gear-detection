
import cv2
import numpy as np
import os
import random

def create_image(label, path, n=20):
    for i in range(n):
        img = np.ones((200,200,3), dtype=np.uint8)*255

        # face
        cv2.circle(img,(100,100),50,(200,180,160),-1)

        if label == "helmet":
            cv2.rectangle(img,(60,30),(140,80),(0,0,255),-1)
        elif label == "mask":
            cv2.rectangle(img,(70,100),(130,130),(255,0,0),-1)

        cv2.imwrite(os.path.join(path,f"{label}_{i}.png"),img)

base="dataset/images"

create_image("helmet", os.path.join(base,"with_helmet"))
create_image("nomask", os.path.join(base,"without_mask"))
create_image("mask", os.path.join(base,"with_mask"))
create_image("nohelmet", os.path.join(base,"without_helmet"))

print("Dataset created")
