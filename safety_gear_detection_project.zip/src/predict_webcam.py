
import cv2
import joblib
import numpy as np

model=joblib.load("src/models/helmet_model.pkl")

cap=cv2.VideoCapture(0)

while True:
    ret,frame=cap.read()
    if not ret:
        break

    img=cv2.resize(frame,(64,64)).flatten().reshape(1,-1)
    pred=model.predict(img)[0]

    label="Helmet" if pred==1 else "No Helmet"

    cv2.putText(frame,label,(20,40),cv2.FONT_HERSHEY_SIMPLEX,1,(0,255,0),2)
    cv2.imshow("Detection",frame)

    if cv2.waitKey(1)==27:
        break

cap.release()
cv2.destroyAllWindows()
