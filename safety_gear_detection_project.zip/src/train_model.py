
import os
import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
import cv2
import joblib

def load_data(folder, label):
    X=[]
    y=[]
    for file in os.listdir(folder):
        img=cv2.imread(os.path.join(folder,file))
        img=cv2.resize(img,(64,64)).flatten()
        X.append(img)
        y.append(label)
    return X,y

def train():
    X,y=[],[]

    paths=[
        ("dataset/images/with_helmet",1),
        ("dataset/images/without_helmet",0),
    ]

    for p,l in paths:
        Xi,yi=load_data(p,l)
        X+=Xi
        y+=yi

    X=np.array(X)
    y=np.array(y)

    Xtrain,Xtest,ytrain,ytest=train_test_split(X,y,test_size=0.2)

    model=LogisticRegression(max_iter=500)
    model.fit(Xtrain,ytrain)

    os.makedirs("src/models",exist_ok=True)
    joblib.dump(model,"src/models/helmet_model.pkl")

    print("Accuracy:",model.score(Xtest,ytest))

if __name__=="__main__":
    train()
